# Hello World
or Hello to you and welcome to my blog where I write stuff and maybe might just ramble on about stuff.
