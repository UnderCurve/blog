# My Blog Page
I write things sometimes.
