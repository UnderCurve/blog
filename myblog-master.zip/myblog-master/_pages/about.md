---
permalink: /about/
title: "About"
---

Hello, I'm a young self-taught/still learning programmer. I mainly code in HTML, CSS, and JavaScript. But I do know a little bit about ExpressJS and Python. I also use the Minecraft coding plugin called Skript.
